import React from "react";

function index() {
  return <h1>Home Page</h1>;
}

export default index;
